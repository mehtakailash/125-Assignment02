package com.scg.util;

/**
* Class to store the address.
*
* @author  Kailash Mehta
* @version 1.0
* @since   2019-04-11 
*/
public class Address {
	String street;
	String city;
	StateCode state;
	String postalCode;
	
	/**
	  * Address constructor representing address.  
	  * Street, City, State and Postal may not be null.
	  *
	  * @throws NullPointerException if any of address fields are null.
	  */
	public Address( String street, String city, StateCode state, String postalCode ) {
		this.street = street;
		this.city = city;
		this.state = state;
		this.postalCode = postalCode;
		
		if (this.street == null) {
		      throw new IllegalArgumentException(
		          "Street is null");
		    }
		if (this.city == null) {
		      throw new IllegalArgumentException(
		          "City is null");
		    }
		if (this.state == null) {
		      throw new IllegalArgumentException(
		          "State is null");
		    }
		
		if (this.postalCode == null) {
		      throw new IllegalArgumentException(
		          "Postal code is null");
		    }
	}
	
	/**
	 * Returns the street name.
	 * @return street
	 */
	public String getStreetNumber() {
		return street;
	}
	
	/**
	 * Returns the City name.
	 * @return city
	 */
	public String getCity() {
		return city;
	}
	
	/**
	 * Returns the State name.
	 * @return state
	 */
	public StateCode getState() {
		return state;
	}
	
	/**
	 * Returns the Postal Code.
	 * @return postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}
	
	@Override
	public String toString() {
		String address = street + '\n' + city + "," + state +" " + postalCode;
		
		return address;
	}
	
//ToDo: @KailashM Delete before submit
//	public static void main (String[] args)
//	{
//		state = state.WA;
//		Address a = new Address("apple Mock Lane","bell",state,"98204");
//		System.out.println(a.toString());
//	}
}
