package com.scg.util;

/**
* Class to the Personal Data.
*
* @author  Kailash Mehta
* @version 1.0
* @since   2019-04-11 
*/
public class PersonalName {
	String first;
	String middle;
	String last;
	
	/**
	  * PersonalName constructors representing Personal Data.  
	  * First, Middle and Last Name may not be null, so substitute the empty string
	  */
	public PersonalName() {
		this.first = "";
		this.middle = "";
		this.last = "";
	}
	
	public PersonalName( String lastName, String firstName ) {
		this.first = firstName;
		this.last = lastName;
		middle = "";
		if (this.first == null) {
			first = "";
		    }
		if (this.last == null) {
			last = "";
		    }
	}
	
	public PersonalName( String lastName, String firstName, String middleName ) {
		this.first = firstName;
		this.middle = middleName;
		this.last = lastName;
		if (this.first == null) {
			first = "";
		    }
		if (this.middle == null) {
			middle = "";
		    }
		if (this.last == null) {
			last = "";
		    }
	}
	
	public String getLastName() {
		return last;
	}
	
	/**
	  * Setter for Last Name.
	  */
	public void setLastName(String lastName) {
		this.last = lastName;
		if (this.last == null) {
			last = "";
		    }
	} 
	
	public String getFirstName() {
		return first;
	}
	
	/**
	  * Setter for First Name.
	  */
	public void setFirstName(String firstName) {
		this.first = firstName;
		if (this.first == null) {
			first = "";
		    }
	}
	
	public String getMiddleName() {
		return middle;
	}
	
	/**
	  * Setter for Middle Name.
	  */
	public void setMiddleName(String middleName) {
		this.middle = middleName;
		if (this.middle == null) {
			middle = "";
		    }
	}
	
	@Override
	public String toString() {
		String lastName = last;
		String firstName = first;
		String personalName;
		if (lastName=="") {
			lastName = "(no last name)";
		}
		if (firstName=="") {
			firstName = "(no first name)";
		}
		personalName = lastName + "," + " " + firstName + " " + middle;
		
		return personalName;
	}
//ToDo: @KailashM Delete before submit
//	public static void main (String[] args)
//	{
//		PersonalName a = new PersonalName(null,null);
//		System.out.println(a.toString());
//	}
}
