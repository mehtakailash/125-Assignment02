/**
 * 
 */
package com.scg.domain;

import java.time.LocalDate;

/**
* Class to store Client Account information.
*
* @author  Kailash Mehta
* @version 1.0
* @since   2019-04-19 
*/
public class ConsultantTime {
	private LocalDate date;
	private Account account;
	private Skill skill; 
	private int hours;
	
	 /**
	  * ConsultantTime constructor representing Consultant's Time detail.  
	  * Name, Contact person, and Address. 
	  * 
	  * @throws IllegalArgumentException if no of hours is 0 or less.
	  */
	public ConsultantTime( LocalDate date, Account account, Skill skill, int hours ) {
			this.date = date;
			this.account = account;
			this.skill = skill;
			this.hours = hours;
		
			if (!this.isBillable()) {
				this.skill= Skill.UNKNOWN_SKILL;
			    }
			
			if (this.hours <= 0) {
			      throw new IllegalArgumentException("Zero working hours");
			    }
		}
	
	/**
	 * Setter for date.
	 */
	public void setDate(LocalDate date) {
//		The new date for this object.
		this.date = LocalDate.now();
	}
	
	/**
	 * Returns date.
	 * @return date
	 */
	public LocalDate getDate() {
		return date;
	}
	
	/**
	 * Setter for account.
	 */
	public void setAccount(Account account) {
//		The new account for this object. 
		this.account = account;
	}

	/**
	 * Returns account.
	 * @return account
	 */
	public Account getAccount() {
		return account;
	}
	
	/**
	 * Setter for no of hours worked.
	 */
	public void setHours(int hours) {
//		The new hours for this object. 
		this.hours = hours;
		
		if (this.hours <= 0) {
		      throw new IllegalArgumentException("Zero working hours");
		    }
	}
	
	/**
	 * Returns for no of hours worked.
	 * @return hours
	 */
	public int getHours() {
		return hours;
	}
	
	/**
	 * Setter for skill.
	 */
	public void setSkill( Skill skill ) {
//		The new skill for this object. 
		this.skill = skill;
	}

	/**
	 * Returns skill.
	 * @return skill
	 *///		if (this.hours > 0) {
//	return true;
//    }
	public Skill getSkill() {
		return skill;
	}
	
	public boolean isBillable() {
		return account.isBillable();
	}
	
	@Override
	public boolean equals( Object obj ) {
//		Overrides Object.equals( Object ). Determines whether this Consultant is equal to a given object. 
//		The two objects are equal if they are both concrete Consultant objects, and all their corresponding properties are equal. 
		if (this == obj) return true;
        if (!(obj instanceof ConsultantTime)) return false;
        
        ConsultantTime consultantTime = (ConsultantTime) obj;
        if (hours != consultantTime.hours) return false;
        if (account != null ? !account.equals(consultantTime.account) : consultantTime.account != null) return false;
        if (date != null ? !date.equals(consultantTime.date) : consultantTime.date != null) return false;
        if (skill != consultantTime.skill) return false;
     
		return true;
	}
	
	@Override
	public int hashCode() {
//		Overrides Object.hashCode. This override is required because the class overrides Object.equals. 
		int result = date.hashCode();
		
		return result;
	}
	
	//ToDo: @KailashM Delete before submit
//	public static void main (String[] args)
//	{
//		LocalDate date = LocalDate.now();
//		Skill[] skill = Skill.values();
//		for ( Skill skills : skill  )
//		    {
//			  ConsultantTime a = new ConsultantTime( date, null, skills, 10);
//			  System.out.println(a.isBillable());
//		    }
//	}
} 
