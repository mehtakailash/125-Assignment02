package com.scg.util;

public enum StateCode {
	WA, // Washington
    CA, // California
    OR, // Oregon
    NY, // New York
    AZ, // Arizona
    ID, // Idaho
}
