/**
 * 
 */
package com.scg.util;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


/**
 * @author kailashm
 *
 */
class AddressTest {
	
	private static final String     STREET     = "123 test";
    private static final String     CITY       = "Bellevue";
    private static final StateCode  STATE      = StateCode.WA;
    private static final String     ZIP        = "98207";

    Address address = new Address(STREET,CITY,STATE,ZIP);
    
	@Test 
	void testConstructNullValues() {
		assertThrows(IllegalArgumentException.class, ()-> new Address(null,null,null,null));
		assertThrows(IllegalArgumentException.class, ()-> new Address(STREET,null,null,null));
		assertThrows(IllegalArgumentException.class, ()-> new Address(STREET,CITY,null,null));
		assertThrows(IllegalArgumentException.class, ()-> new Address(STREET,CITY,STATE,null));
	}
	
	/**
	 * Test method for {@link com.scg.util.Address#getStreetNumber()}.
	 */
	@Test 
	void testGetStreetNumber() {
		assertNotNull(address.getStreetNumber());
		assertEquals( STREET, address.getStreetNumber() );
	}

	
	/**
	 * Test method for {@link com.scg.util.Address#getCity()}.
	 */
	@Test
	void testGetCity() {
		assertNotNull(address.getCity());
		assertEquals( CITY, address.getCity() );
	}

	/**
	 * Test method for {@link com.scg.util.Address#getState()}.
	 */
	@Test
	void testGetState() {
		assertNotNull(address.getState());
		assertEquals( STATE, address.getState() );
	}

	/**
	 * Test method for {@link com.scg.util.Address#getPostalCode()}.
	 */
	@Test
	void testGetPostalCode() {
		assertNotNull(address.getPostalCode());
		assertEquals( ZIP, address.getPostalCode() );
	}
	
	@Test
	void testToString() {
		assertNotNull(address.toString());
	}	
}
